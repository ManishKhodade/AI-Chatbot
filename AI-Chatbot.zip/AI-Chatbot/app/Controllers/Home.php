<?php

namespace App\Controllers;
use GuzzleHttp\Client;

class Home extends BaseController
{

    public function index(): string
    {
        return view('chatbot');
    }

     public function ask()
    {
        $question = $this->request->getPost('question');

        // Either get from environment or set directly
        // Option 1: From environment (.env)
        // $apiKey = getenv('GEMINI_API_KEY');

        // Option 2: Directly (not recommended for production)
        $apiKey = "AIzaSyB0irmLWr4HiXwY98iag7GlTDazMhgTE1U";

        try {
            $client = new Client();
            $response = $client->post(
                "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key={$apiKey}",
                [
                    'headers' => [
                        'Content-Type' => 'application/json',
                    ],
                    'json' => [
                        'contents' => [
                            ['parts' => [['text' => $question]]]
                        ]
                    ]
                ]
            );

            $data = json_decode($response->getBody(), true);

            // Log full API response for debugging
            file_put_contents(WRITEPATH.'logs/chatbot_debug.txt', print_r($data, true));

            // Default answer if API response is not as expected
            $answer = "Sorry, I couldn't find an answer.";

            if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
                $answer = $data['candidates'][0]['content']['parts'][0]['text'];
            }

            return $this->response->setJSON(['answer' => $answer]);

        } catch (\Exception $e) {
            // Log error for debugging
            file_put_contents(WRITEPATH.'logs/chatbot_error.txt', $e->getMessage());

            return $this->response->setJSON([
                'answer' => "Error: " . $e->getMessage()
            ]);
        }
    }
}
