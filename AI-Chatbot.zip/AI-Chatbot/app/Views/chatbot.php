<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI Chatbot | Manish Khodade</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

  <style>
    * {
      font-family: 'Poppins', sans-serif;
    }

    body {
      background: linear-gradient(135deg, #1f2937, #111827);
      color: #fff;
      min-height: 100vh;
    }

    .navbar {
      background: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(10px);
    }

    .hero-section {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 90vh;
      text-align: center;
      padding: 20px;
    }

    .hero-section h1 {
      font-size: 3rem;
      font-weight: 700;
      color: #00d8ff;
    }

    .hero-section p {
      font-size: 1.2rem;
      max-width: 700px;
      margin-top: 15px;
      color: #d1d5db;
    }

    /* Large Try Chatbot button */
    .btn-custom {
      background-color: #00d8ff;
      border: none;
      color: #111827;
      font-weight: 600;
      margin-top: 25px;
      padding: 15px 40px;
      border-radius: 12px;
      font-size: 1.2rem;
      box-shadow: 0 4px 12px rgba(0, 216, 255, 0.4);
      transition: all 0.3s ease;
    }

    .btn-custom:hover {
      background-color: #38bdf8;
      transform: scale(1.05);
      box-shadow: 0 6px 16px rgba(0, 216, 255, 0.5);
    }

    footer {
      text-align: center;
      padding: 20px;
      background-color: #0f172a;
      font-size: 0.9rem;
      color: #94a3b8;
    }

    /* Small Floating Ask Me Button */
    .askme-btn {
      position: fixed;
      bottom: 30px;
      right: 30px;
      background-color: #00d8ff;
      color: #111827;
      border: none;
      border-radius: 50%;
      width: 60px;
      height: 60px;
      font-weight: bold;
      font-size: 1.2rem;
      cursor: pointer;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
      transition: 0.3s;
    }

    .askme-btn:hover {
      transform: scale(1.1);
    }

    /* Chatbox */
    .chatbox {
      position: fixed;
      bottom: 100px;
      right: 30px;
      width: 320px;
      height: 420px;
      background-color: #1e293b;
      border-radius: 12px;
      display: none;
      flex-direction: column;
      box-shadow: 0 0 15px rgba(0,0,0,0.5);
    }

    .chatbox-header {
      background-color: #00d8ff;
      color: #111827;
      font-weight: bold;
      padding: 10px;
      border-radius: 12px 12px 0 0;
    }

    .chatbox-messages {
      flex: 1;
      padding: 10px;
      overflow-y: auto;
      color: #e5e7eb;
      font-size: 0.9rem;
    }

    .chatbox-input {
      display: flex;
      border-top: 1px solid #374151;
    }

    .chatbox-input input {
      flex: 1;
      padding: 10px;
      border: none;
      background-color: #111827;
      color: #fff;
    }

    .chatbox-input button {
      padding: 10px 15px;
      border: none;
      background-color: #00d8ff;
      color: #111827;
      font-weight: bold;
      cursor: pointer;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar navbar-dark navbar-expand-lg">
    <div class="container">
      <a class="navbar-brand fw-bold text-info" href="#">Manish Khodade</a>
    </div>
  </nav>

  <!-- Hero Section -->
  <section class="hero-section">
    <h1>Welcome to My AI Chatbot Project 🤖</h1>
    <p>Built using CodeIgniter 4, PHP, MySQL, Bootstrap, and integrated with Google Gemini API for real-time intelligent responses.</p>
    <a href="#chat" class="btn btn-custom" id="tryChatBtn">Try Chatbot</a>
  </section>

  <!-- Footer -->
  <footer>
    © 2025 Manish Khodade. All rights reserved.
  </footer>

  <!-- Chatbot Floating Button -->
  <button class="askme-btn" id="askmeBtn">💬</button>

  <!-- Chatbox -->
  <div class="chatbox" id="chatbox">
    <div class="chatbox-header">
      Ask Me <span style="float:right;cursor:pointer;" id="closeChat">&times;</span>
    </div>
    <div class="chatbox-messages" id="chatMessages"></div>
    <div class="chatbox-input">
      <input type="text" id="chatInput" placeholder="Type your question...">
      <button id="sendBtn">Send</button>
    </div>
  </div>
 
  <script>
  function openChatbox() {
    document.getElementById("chatbox").style.display = "flex";
  }

  function closeChatbox() {
    document.getElementById("chatbox").style.display = "none";
  }

  document.getElementById("askmeBtn").addEventListener("click", openChatbox);
  document.getElementById("tryChatBtn").addEventListener("click", function(e) {
    e.preventDefault();
    openChatbox();
  });
  document.getElementById("closeChat").addEventListener("click", closeChatbox);

  // Actual chat message send
  document.getElementById("sendBtn").addEventListener("click", function() {
    let input = document.getElementById("chatInput");
    let msg = input.value.trim();

    if (msg !== "") {
      let chatMessages = document.getElementById("chatMessages");
      chatMessages.innerHTML += "<p><b>You:</b> " + msg + "</p>";
      input.value = "";

      // Call backend API (CodeIgniter route)
      fetch("<?= base_url('chatbot/ask') ?>", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "question=" + encodeURIComponent(msg)
      })
      .then(res => res.json())
      .then(data => {
        chatMessages.innerHTML += "<p><b>Bot:</b> " + data.answer + "</p>";
        chatMessages.scrollTop = chatMessages.scrollHeight;
      })
      .catch(err => {
        chatMessages.innerHTML += "<p><b>Bot:</b> Error connecting to server!</p>";
      });
    }
  });
</script>

</body>
</html>
